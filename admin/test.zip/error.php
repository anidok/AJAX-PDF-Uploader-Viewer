<html lang="en">
  <head>
    <meta charset="utf-8" >
    <title>Web service test | Admin Login</title>
    <link rel="stylesheet" href="style.css"></link>
  </head>
  <body>
    <div align="center">
      <p class="title">Admin Login</p>
      <p>Invalid login details provided!</p>
      <div>
        <a href="index.php">Go Back</a> to Login Page.
      </div>
    </div>
  </body>
</html>
